

    <!--breadcrumbs start-->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-4">
                    <h1>Contacts</h1>
                </div>
                <div class="col-lg-8 col-sm-8">
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">Contacts</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs end-->

    <!--google map start-->
     <div class="contact-map">
         <div id="map-canvas" style="width: 100%; height: 400px"></div>
     </div>
     <!--google map end-->

     <!--container start-->
    <div class="container">


        <div class="row">
            <div class="col-lg-5 col-sm-5 address">
                <h4>New Yourk</h4>
                <p>
                    Jonathon Smith <br/>
                    Street Address 228 Park Avenue South New York, <br/>
                    NY 10003-1502.
                </p>
                <br>
                <br>
                <br>
                <p>
                    Phone <br/>
                    <span class="muted">(212) 210-2100</span><br/>
                    Fax <br/>
                    <span class="muted">212-995-4794.</span><br/>
                    Email <br/>
                    <span class="muted">info@domain.com</span>
                </p>
            </div>
            <div class="col-lg-7 col-sm-7 address">
                <h4>Send a Message</h4>
                <div class="contact-form">
                    
                    
                     
                     <?php echo validation_errors(); ?> 
                    <?php echo $this->session->flashdata('email_sent'); ?> 
                      <?php echo form_open('hemantcontroller/contact',array("name"=>"contact","method"=>"post","role"=>"form")) ?>
                                
     
                        <div class="form-group">
                            <label for="name">Name</label>
                            <?php echo form_input(array("name"=>"name","type"=>"text","class"=>"form-control","id"=>"name"))?>
                            
                           
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                     
                            
                   <?php echo form_input(array("name"=>"email","type"=>"email","class"=>"form-control","id"=>"email"))?>          
                            
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            
                            <?php echo form_input(array("name"=>"phone","type"=>"text","class"=>"form-control","id"=>"phone"))?>          
                        </div>
                        <div class="form-group">
                            <label for="phone">Message</label>
                            
                             
                            <?php echo form_textarea(array("name"=>"message","class"=>"form-control","rows"=>"5","cols"=>"5"))?>          
                            
                        </div>
                     
                         <?php echo form_submit(array("name"=>"submit","class"=>"btn btn-danger","type"=>"submit","value"=>"Contact"))?>          
                    <?php echo form_close()?>

                </div>
            </div>
        </div>

    </div>
    <!--container end-->

    