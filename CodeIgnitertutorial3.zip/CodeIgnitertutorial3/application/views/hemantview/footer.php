<!--footer start-->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-3">
                    <h1>contact info</h1>
                    <address>
                        <p>Address: No.28-63877 street</p>
                        <p>lorem ipsum city, Country</p>

                        <p>Phone : (123) 456-7890</p>
                        <p>Fax : (123) 456-7890</p>
                        <p>Email : <a href="javascript:;">support@vectorlab.com</a></p>
                    </address>
                </div>
                <div class="col-lg-5 col-sm-5">
                    <h1>Quick 
                    links</h1>
                    <div class="tweet-box">
                        
                       
                        
                        
                        
                       
                       <?php echo  anchor('hemantcontroller/index','Home');?><br/>
                       <?php echo anchor('hemantcontroller/about','About')?><br/>
                       <?php echo anchor('hemantcontroller/portfolio','Portfolio') ?><br/>
                       <?php echo anchor('hemantcontroller/contact','Contact') ?>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-3 col-lg-offset-1">
                    <h1>stay connected</h1>
                    <ul class="social-link-footer list-unstyled">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                       
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!--footer end-->

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url()?>/application/views/hemantview/js/jquery.js"></script>
    <script src="<?php echo base_url()?>/application/views/hemantview/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo base_url()?>/application/views/hemantview/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/application/views/hemantview/js/hover-dropdown.js"></script>
    <script defer src="<?php echo base_url()?>/application/views/hemantview/js/jquery.flexslider.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/application/views/hemantview/assets/bxslider/jquery.bxslider.js"></script>

    <script type="text/javascript" src="<?php echo base_url()?>/application/views/hemantview/js/jquery.parallax-1.1.3.js"></script>

    <script src="<?php echo base_url()?>/application/views/hemantview/js/jquery.easing.min.js"></script>
    <script src="<?php echo base_url()?>/application/views/hemantview/js/link-hover.js"></script>

    <script src="<?php echo base_url()?>/application/views/hemantview/assets/fancybox/source/jquery.fancybox.pack.js"></script>

    <script type="text/javascript" src="<?php echo base_url()?>/application/views/hemantview/assets/revolution_slider/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/application/views/hemantview/assets/revolution_slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

    <!--common script for all pages-->
    <script src="<?php echo base_url()?>/application/views/hemantview/js/common-scripts.js"></script>

    <script src="<?php echo base_url()?>/application/views/hemantview/js/revulation-slide.js"></script>


  <script>

      RevSlide.initRevolutionSlider();

      $(window).load(function() {
          $('[data-zlname = reverse-effect]').mateHover({
              position: 'y-reverse',
              overlayStyle: 'rolling',
              overlayBg: '#fff',
              overlayOpacity: 0.7,
              overlayEasing: 'easeOutCirc',
              rollingPosition: 'top',
              popupEasing: 'easeOutBack',
              popup2Easing: 'easeOutBack'
          });
      });

      $(window).load(function() {
          $('.flexslider').flexslider({
              animation: "slide",
              start: function(slider) {
                  $('body').removeClass('loading');
              }
          });
      });

      //    fancybox
      jQuery(".fancybox").fancybox();



  </script>

  </body>
</html>
