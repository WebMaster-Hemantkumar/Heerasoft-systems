  <div class="fullwidthbanner-container main-slider">
         <div class="fullwidthabnner">
             <ul id="revolutionul" style="display:none;">
                 <!-- 1st slide -->
                 <li data-transition="fade" data-slotamount="8" data-masterspeed="700" data-delay="9400" data-thumb="">
                     <div class="caption lfl slide_item_left"
                          data-x="10"
                          data-y="70"
                          data-speed="400"
                          data-start="1500"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/ban2.png" alt="Image 1">
                     </div>
                     <div class="caption lfr slide_title"
                          data-x="640"
                          data-y="120"
                          data-speed="400"
                          data-start="1000"
                          data-easing="easeOutExpo">
                        Digital Solutions.Empower Business.
                     </div>

                     <div class="caption lfr slide_subtitle dark-text"
                          data-x="640"
                          data-y="190"
                          data-speed="400"
                          data-start="2000"
                          data-easing="easeOutExpo">
                      <p style=" 
    font-family: sans-serif;color:#FAE15F "> Build and manage better websites with Us<p>
                     </div>
                     <div class="caption lfr slide_desc"
                          data-x="640"
                          data-y="260"
                          data-speed="400"
                          data-start="2500"
                          data-easing="easeOutExpo">
                         <p style=" font-size: 17px;
    font-family: sans-serif;">we offer premium web development packages at very affordable rates<br />
                          We develop informative and Ecommerce websites 
we have highly <br />professional and experts
Developers for project delivery.</p>
                     </div>
                     

                 </li>

                 <!-- 2nd slide  -->
                 <li data-transition="fade" data-slotamount="8" data-masterspeed="700" data-delay="9400" data-thumb="">
                     <!-- THE MAIN IMAGE IN THE FIRST SLIDE -->
                     <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/banner_bg.jpg" alt="">
                     <div class="caption lft slide_title"
                          data-x="10"
                          data-y="125"
                          data-speed="400"
                          data-start="1500"
                          data-easing="easeOutExpo">
                         Online Business Made Simple
                     </div>
                     <div class="caption lft slide_subtitle dark-text"
                          data-x="10"
                          data-y="180"
                          data-speed="400"
                          data-start="2000"
                          data-easing="easeOutExpo">
                       <p style=" 
    font-family: sans-serif;color:#E9AD7B"> 


Powerful Websites with Self-manageable Features</p>
                     </div>
                     <div class="caption lft slide_desc dark-text"
                          data-x="10"
                          data-y="240"
                          data-speed="400"
                          data-start="2500"
                          data-easing="easeOutExpo">
                         <p style=" font-size: 17px;
    font-family: sans-serif;color: #ffffff"> Attract & Convert More Customers With Results Driven Website
                   
                        with fixed </br>   ongoing prices you can budget for.</p>
                     </div>
                     
                     <div class="caption lft start"
                          data-x="640"
                          data-y="55"
                          data-speed="400"
                          data-start="2000"
                          data-easing="easeOutBack"  >
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/man.png" alt="man">
                     </div>
                     <div class="caption lft slide_item_right"
                          data-x="330"
                          data-y="20"
                          data-speed="500"
                          data-start="5000"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/test_man.png" id="rev-hint2" alt="txt img">
                     </div>

                 </li>

                 <!-- 3rd slide  -->
                 <li data-transition="fade" data-slotamount="7" data-masterspeed="300" data-delay="9400" data-thumb="">
                     <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/red-bg.jpg" alt="">
                     <div class="caption lfl slide_item_right"
                          data-x="10"
                          data-y="105"
                          data-speed="1200"
                          data-start="1500"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/imac.png" alt="Image 1">
                     </div>
                     <div class="caption lfl slide_item_right"
                          data-x="25"
                          data-y="345"
                          data-speed="1200"
                          data-start="2000"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/tab.png" alt="Image 1">
                     </div>
                     <div class="caption lfl slide_item_right"
                          data-x="200"
                          data-y="330"
                          data-speed="1200"
                          data-start="2500"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/mobile.png" alt="Image 1">
                     </div>
                     <div class="caption lfl slide_item_right"
                          data-x="250"
                          data-y="230"
                          data-speed="1200"
                          data-start="3000"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/laptop.png" alt="Image 1">
                     </div>
                     <div class="caption lfl slide_item_right"
                          data-x="165"
                          data-y="30"
                          data-speed="500"
                          data-start="5000"
                          data-easing="easeOutBack">
                         <img src="<?php echo base_url()?>/application/views/hemantview/img/banner/text_imac.png" id="rev-hint1" alt="Image 1">
                     </div>

                     <div class="caption lfr slide_title slide_item_left yellow-txt"
                          data-x="670"
                          data-y="145"
                          data-speed="400"
                          data-start="3500"
                          data-easing="easeOutExpo">
                         Responsive Website Development
                     </div>
                     <div class="caption lfr slide_subtitle slide_item_left"
                          data-x="670"
                          data-y="200"
                          data-speed="400"
                          data-start="4000"
                          data-easing="easeOutExpo">
                         A Fully Responsive website
                     </div>
                     <div class="caption lfr slide_desc slide_item_left"
                          data-x="670"
                          data-y="280"
                          data-speed="400"
                          data-start="4500"
                          data-easing="easeOutExpo">
                        <p style=" font-size: 17px;
    font-family: sans-serif;"> Get a professional website built with a smart and effective strategy <br>
                         and real, measurable results for your  business.</p>
                     </div>


                 </li>

             </ul>
            <div class="tp-bannertimer tp-top"></div>
         </div>
     </div>