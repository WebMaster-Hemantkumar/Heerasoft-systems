<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="HeeraSoft, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="<?php echo base_url()?>/application/views/hemantview/img/favicon.png">

    <title>HeeraSoft Technologies</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url()?>/application/views/hemantview/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>/application/views/hemantview/css/theme.css" rel="stylesheet">
    <link href="<?php echo base_url()?>/application/views/hemantview/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo base_url()?>/application/views/hemantview/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url()?>/application/views/hemantview/css/flexslider.css"/>
    <link href="<?php echo base_url()?>/application/views/hemantview/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>/application/views/hemantview/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo base_url()?>/application/views/hemantview/assets/revolution_slider/css/rs-style.css" media="screen">
    <link rel="stylesheet" href="<?php echo base_url()?>/application/views/hemantview/assets/revolution_slider/rs-plugin/css/settings.css" media="screen">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url()?>/application/views/hemantview/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url()?>/application/views/hemantview/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
    <!--header start-->
    <header class="header-frontend">
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="fa fa-bars"></span>
                    </button>
                    

                    <?php echo  anchor('hemantcontroller/index','Heera<span>Soft</span>','class="navbar-brand"');?>


                </div>
                
                <div class="navbar-collapse collapse ">
               
                    <ul class="nav navbar-nav">
                    <p style="position:absolute;right: 125px;top: 5px">
                 <i class=" fa fa-mobile" style="color: #F77B6F;font-size: 16px">&nbsp;&nbsp;+91- 9205262451</i>&nbsp;&nbsp;<i class=" fa fa-envelope" style="color: #F77B6F;font-size: 17px">&nbsp;info@heerasofttechnologies.com</i></p>
                 <br/>
                 
                     
                       
                        <li class="active"><?php echo  anchor('hemantcontroller/index','Home');?></li>

                        <li><?php echo anchor('hemantcontroller/about','About')?></li>

                        <li><?php echo anchor('hemantcontroller/services','Services')?></li>

                        <li><?php echo anchor('hemantcontroller/portfolio','Portfolio') ?></li>

                        <li><?php echo anchor('hemantcontroller/blog','Blog') ?></li>
                        
                        <li><?php echo anchor('hemantcontroller/contact','Contact') ?></li>
                        
                        <li><?php echo anchor('hemantcontroller/register','Register') ?></li>
                        
                        
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <!--header end-->