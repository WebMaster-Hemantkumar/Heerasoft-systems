<!DOCTYPE html>
<html lang="en">
<head>
  <title>Contacts</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<script src="https://use.fontawesome.com/c49c419ce5.js"></script>

</head>
<body>

<div class="container">
  
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Message</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
    foreach($result as $r){
    ?>
      <tr>
        <td class="success"><?php echo $r->name?></td>
        <td class="danger"><?php echo $r->email ?></td>
        <td class="info"><?php echo $r->phone?></td>
        <td class="warning"><?php echo $r->message?></td>
        <td><?php echo anchor('hemantcontroller/delete/'.$r->id,'<i class="fa fa-trash" aria-hidden="true" style="color:red;font-size:30px"></i>')?></td>
        <td><td><?php echo anchor('hemantcontroller/edit/'.$r->id,'<i class="fa fa-pencil" aria-hidden="true"></i>
')?></td>
        
      </tr>    
      
     <?php }?>
      
    </tbody>
  </table>
</div>

</body>
</html>

