 <div class="container">
        <div class="row">
            <!--feature start-->
            <div class="text-center feature-head">
                <h1 style="color: #D95F38">Get a professional website built with a smart and effective strategy ensuring real, measurable results for your  business.</h1>
                
            </div>
            <div class="col-lg-4 col-sm-4">
                <section>
                    <div class="f-box">
                        <i class=" fa fa-desktop"></i>
                        <h2>Web Design</h2>
                    </div>
                    <p class="f-text">We offer premium web development packages at very affordable rates.
                    E-commerce Web Design, Custom Website Templates Design, E-mail Newsletter Design.</p>
                </section>
            </div>
            <div class="col-lg-4 col-sm-4">
                <section>
                    <div class="f-box active">
                        <i class=" fa fa-code"></i>
                        <h2>Web Development</h2>
                    </div>
                    <p class="f-text">We develop informative and E-commerce websites. 
                    We have highly professional and experts Developers for project delivery.</p>
                </section>
            </div>
            <div class="col-lg-4 col-sm-4">
                <section>
                    <div class="f-box">
                        <i class="fa fa-gears"></i>
                        <h2>Digital Marketing</h2>
                    </div>
                    <p class="f-text">By social media increase your brand recognition. 
                    Improve brand loyalty and maximise the business conversation opportunities.</p>
                </section>
            </div>

 <div class="col-lg-4 col-sm-4">
                <section>
                    <div class="f-box">
                        <i class=" fa fa-desktop"></i>
                        <h2>Graphic Design</h2>
                    </div>
                    <p class="f-text">Our graphic design solutions include brochure design, 
                    business cards, logo design, banner ads, icon design and more.</p>
                </section>
            </div>
            <div class="col-lg-4 col-sm-4">
                <section>
                    <div class="f-box active">
                        <i class=" fa fa-code"></i>
                        <h2>Mobile App Development</h2>
                    </div>
                    <p class="f-text">We developed a comprehensive suite with numerous tools
                    for creating world class mobile and desktop applications 
                    with experienced web application team.</p>
                </section>
            </div>
            <div class="col-lg-4 col-sm-4">
                <section>
                    <div class="f-box">
                        <i class="fa fa-gears"></i>
                        <h2>Content Writing</h2>
                    </div>
                    <p class="f-text">Customers are building trust with those brands that are providing 
                    genuinely valuable, extremely relevant and constantly engaging content. 
                    Are you one of these brands? If not, we can help.</p>
                </section>
            </div>
            <!--feature end-->
        </div>
      <br/><br/>
    </div>


    <!--property start-->
    <div class="property gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-6 text-center">
                    <img src="<?php echo base_url()?>/application/views/hemantview/img/HeeraSoft.png" alt="" class="img-responsive">
                </div>
                <div class="col-lg-6 col-sm-6">
                    <h1 style="padding-left: 190px;color: #CC4F26">Build and manage better websites with Us</h1>
                    <p style="padding-left: 190px;font-family: sans-serif;font-size: 17px">Isn’t It About Time A WebSite Development Company Put You And Your Business First ?</p>
                   <p style="padding-left: 190px;font-family: sans-serif;font-size: 15px">If you’re fed up with trying to grow with a website presence that just doesn’t generate new business, get in touch and find out how we can help you get it right.</p>
                   <h1 style="padding-left: 190px;color:#FF9901">Speak to our web experts: +91-9205262451</h1>
                </div>
            </div>
        </div>
    </div>
    <!--property end-->

     

     <!--parallax start-->
     <section class="parallax1">
         <div class="container">
             <div class="row">
                 <h1 style="color:#E6662D">Our ecommerce platform is filled with useful features which will enable you to easily engage with your customers. We help you choose the features based on strategic decision on customer and business needs.</h1>
             </div>
         </div>
     </section>
     <!--parallax end-->

     <div class="container">
         <!--clients start-->
         <div class="clients">
             <div class="container">
                 <div class="row">
                     <div class="col-lg-12 text-center">
                         <ul class="list-unstyled">
                             <li><a href="#"><img src="<?php echo base_url()?>/application/views/hemantview/img/clients/logo1.png" alt=""></a></li>
                             <li><a href="#"><img src="<?php echo base_url()?>/application/views/hemantview/img/clients/logo2.png" alt=""></a></li>
                             <li><a href="#"><img src="<?php echo base_url()?>/application/views/hemantview/img/clients/logo3.png" alt=""></a></li>
                             <li><a href="#"><img src="<?php echo base_url()?>/application/views/hemantview/img/clients/logo4.png" alt=""></a></li>
                             <li><a href="#"><img src="<?php echo base_url()?>/application/views/hemantview/img/clients/logo5.png" alt=""></a></li>
                         </ul>
                     </div>
                 </div>
             </div>
         </div>
         <!--clients end-->
     </div>