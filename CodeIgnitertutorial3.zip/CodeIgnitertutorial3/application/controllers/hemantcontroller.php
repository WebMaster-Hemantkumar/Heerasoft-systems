<?php

class hemantcontroller extends CI_Controller
{

// for loding model
public function __construct()
{
parent::__construct();
$this->load->model('contactmodel');
$this->load->library('session'); 
}


public function index()
{
$this->load->view('hemantview/header');
$this->load->view('hemantview/slider');
$this->load->view('hemantview/index');
$this->load->view('hemantview/footer');
}


public function about()
{
$this->load->view('hemantview/header');
$this->load->view('hemantview/about');
$this->load->view('hemantview/footer');
}


public function services()
{
$this->load->view('hemantview/header');
$this->load->view('hemantview/services');
$this->load->view('hemantview/footer');
}


public function portfolio()
{
$this->load->view('hemantview/header');
$this->load->view('hemantview/portfolio');
$this->load->view('hemantview/footer');
}


public function blog()
{
$this->load->view('hemantview/header');
$this->load->view('hemantview/blog');
$this->load->view('hemantview/footer');
}


public function contact()
{
	/*$from_email = "hemantbly.kumar@gmail.com"; 
         $to_email = $this->input->post('email'); 
   
         //Load email library 
         $this->load->library('email'); 
   
         $this->email->from($from_email, 'Hemant kumar'); 
         $this->email->to($to_email);
         $this->email->subject('Email Test'); 
         $this->email->message('This is test mail.'); 
   
         //Send mail 
         if($this->email->send()) 
         $this->session->set_flashdata("email_sent","Email sent successfully."); 
         else 
         $this->session->set_flashdata("email_sent","Error in sending Email."); 
         $this->load->view('contact'); 
	*/
	
	$this->load->library('form_validation');
			
         /* Set validation rule for name field in the form */ 
         $this->form_validation->set_rules('name', 'Name', 'required'); 
         $this->form_validation->set_rules('email', 'Name', 'required'); 
         $this->form_validation->set_rules('phone', 'Name', 'required'); 
         $this->form_validation->set_rules('message', 'Name', 'required'); 
			
	if ($this->form_validation->run() == FALSE) { 
         $this->load->view('hemantview/header');
$this->load->view('hemantview/contact');
$this->load->view('hemantview/footer');
         } 
         /*else { 
            
            redirect('formsuccess'); 
         } */
	
	if(isset($_REQUEST['submit']))
        {
      $this->contactmodel->data_insert();
           
        }
        
        
	
	
}



public function register()
{
$r=$this->contactmodel->data_show();

$this->load->view('hemantview/header');
$this->load->view('hemantview/slider');
$this->load->view('hemantview/register',array('result'=>$r));
$this->load->view('hemantview/footer');
}












}