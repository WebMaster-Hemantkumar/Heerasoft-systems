<?php

class contactmodel extends CI_Model
{
    public function data_insert()
    {
        $name=$_REQUEST['name'];
        $email=$_REQUEST['email'];
        $phone=$_REQUEST['phone'];
        $addres=$_REQUEST['message'];
        
        $data=array(
            "name"=>$name,
            "email"=>$email,
            "phone"=>$phone,
            "message"=>$addres
                
                );
       $re= $this->db->insert('contacts',$data);
       return $re;
       }
       
       
   
          
    //for fetching the data from table
public function data_show()
       {
           
           
           $query="select * from contacts";
           $r=$this->db->query($query);
          $test=$r->result();
           return  $test;
       }
       
       
      //for deleting the perticular id data quary 
 public function data_delete($id)
       {
           $this->db->where('id',$id);
          $r= $this->db->delete('contacts');
          return $r;
       }
       
       //create function for getting data for single id
       
        public function  data_select_single($id)
      {
          $query="select * from register where Id='$id'";
          $r=$this->db->query($query);
          $test=$r->result();
  
            return $test;
      }
       
       //run quary for updating the data
       
        public function  data_update()
      {
        $name=$_REQUEST['nm'];
        $email=$_REQUEST['em'];
        $phone=$_REQUEST['phone'];
        $addres=$_REQUEST['add'];
        
        $id=$_REQUEST['h1'];
        
        $query="update register set name='$name',email='$email',phone='$phone',address='$addres' where Id='$id'  ";
        $r= $this->db->query($query);
       return $r;
      }
       


}